
# README

This file provides information on the third party libraries that ship
with *GrouperShell*.

$Id: README.txt,v 1.2 2006/06/26 15:00:19 blair Exp $

---

## bsh-2.0b4.jar

"Lightweight Scripting for Java"

* Version:  2.0b4 
* Source:   <http://beanshell.org/>
* License:  LGPL

