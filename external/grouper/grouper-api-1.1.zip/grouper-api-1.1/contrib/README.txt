
# Grouper Contributed Code

$Id: README.txt,v 1.1 2006/06/28 18:43:12 blair Exp $

---

## gsh

*gsh* (*GrouperShell*) is a Java-based shell that can be used in both a
batch and interactive manner to administer and interact with the Groups
Registry using the Grouper API.

* Contributor:    blair christensen. <blair@devclue.com>
* Contributed:    20060623
* Last Updated:   20060623
* Version:        0.0.1
* URL:            <http://grouper.devclue.com/>
* See `gsh/README.txt` and `gsh/doc/html/index.html` for more information.

---

## Old

These are contributed code items that are no longer being maintained.
These programs *may not* work without being updated to reflect API
change.

## cdg

*cdg* (*com.devclue.grouper*) is a collection of classes for interacting
with the Grouper API that can be used as either applications or
libraries.  

*cdg* has been deprecated by *GrouperShell*.

Current functionality:
* Add stems, groups, members and (JDBC) subjects
* Query stems, groups, members and subjects

* Contributor:    blair christensen. <blair@devclue.com>
* Contributed:    20051216
* Last Updated:   20051216
* URL:            n/a
* See `cdg/README` and `cdg/doc/html/index.html` for more information.

### load/csv2group

Program to load groups and memberships from a CSV file into the
registry using the Grouper API.

* Contributor:    The University Of Chicago
* Contributed:    20041203
* Last Updated:   20050706
* Deprecated:     20051212
* See `old/load/csv2group/README` for more information

### load/cvs2subject

Program to populate `grouper_subject` table with I2MI Subjects from a
CSV file.

* Contributor:    The University Of Chicago
* Contributed:    20040702
* Last Updated:   20050904
* Deprecated:     20051212
* See `old/load/csv2subject/README` for more information.

### load/groupmgr

Program to add and delete groups, memberships, and attributes.

* Contributor:    The University Of Chicago
* Contributed:    20041207
* Last Updated:   20050706
* Deprecated:     20051212
* See `old/load/groupmgr/README` for more information.

### misc/grouperq

Demonstration program for querying the group registry using the
Grouper API.

* Contributor:    The University Of Chicago
* Contributed:    20041130
* Last Updated:   20050706
* Deprecated:     20051212
* See `old/misc/grouperq/README` for more information.

