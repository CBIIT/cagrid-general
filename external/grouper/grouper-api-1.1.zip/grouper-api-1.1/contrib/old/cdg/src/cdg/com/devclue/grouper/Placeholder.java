/*
 * Copyright (C) 2005 blair christensen.
 * All Rights Reserved.
 * 
 * You may use and distribute under the same terms as Grouper itself.
 */

/**  
 * Exists only to enable package.html to be included in javadoc
 * <p />
 * @author  blair christensen.
 * @version $Id: Placeholder.java,v 1.1 2006/06/23 17:30:10 blair Exp $
 */
class Placeholder { }

